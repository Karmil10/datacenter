
<div class="alert alert-success" role="alert">
  <h1 class="alert-heading"></h1>
  <!-- <div class="text-info text-center"> -->
  <p><h2 class="text-info text-center"><strong>DATA CENTER MANAGEMENT SYSTEM BANK ICBC INDONESIA</h2></strong></p>
  <hr>
  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal">
  <i class="fas fa-tools"> Control Panel </i>
</button>
</div>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="exampleModalLabel"><i class="fas fa-tools"></i>  Control Panel</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div class="row">
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url()."administrator/users/update_aksi";  ?>"><p class="nav-link small text-info">Tambah User</p></a>
           <i class="fas fa-user-graduate fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url()."administrator/users/update/1"; ?>"><p class="nav-link small text-info">Edit User </p></a>
           <i class="fas fa-user-edit fa-3x"></i>
         </div> 
         <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
         <!-- <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> </p></a>
           <i class="fas fa-user-edit fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> </p></a>
           <i class="fas fa-file-alt fa-3x"></i>
         </div>    -->
      <!--  </div><hr>
       <div class="row">
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Report</p></a>
           <i class="fas fa-print fa fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Cetak Report</p></a>
           <i class="fas fa-print fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Kategori</p></a>
           <i class="fas fa-list-ul fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Info </p></a>
           <i class="fas fa-bullhorn fa-3x"></i>
         </div>   
       </div><hr>
       <div class="row">
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> </p></a>
           <i class="fas fa-id-card-alt fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Tentang Pembuat</p></a>
           <i class="fas fa-info-circle fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> </p></a>
           <i class="fas fa-laptop fa-3x"></i>
         </div>   
         <div class="col-md-3 text-info text-center">
           <a href="<?php echo base_url(); ?>"><p class="nav-link small text-info"> Galery</p></a>
           <i class="fas fa-image fa-3x"></i>
         </div>   
       </div>
      </div> -->
     
      
        
      </div>
    </div>
  </div>
</div>
</div>