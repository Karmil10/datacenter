<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><h5>MOHON ISI FORM DI BAWAH INI</h5></title>
</head>

<body>

<table border="1" width="44%" height="456">
	<tr>
		<td>
		<form method="POST" action="--WEBBOT-SELF--">
			<!--webbot bot="SaveResults" U-File="fpweb:///_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
			<p>&nbsp;</p>
		<table border="1" width="100%" height="480" style="border-width: 0px">
			<tr>
				<td colspan="3" height="24" style="border-style: none; border-width: medium">
				<p align="center">MOHON ISI FORM DI BAWAH INI</td>
			</tr>
			<tr>
				<td colspan="3" height="131" style="border-style: none; border-width: medium">
				<p align="center">&nbsp;</td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">NO KTP/SIM</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium"><b>:</b></td>
				<td width="71%" style="border-style: none; border-width: medium">
				<input type="text" name="T1" size="25"></td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">NAMA</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium"><b>:</b></td>
				<td width="71%" style="border-style: none; border-width: medium">
				<input type="text" name="T2" size="25"></td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">PT/Dept/Institusi</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium"><b>:</b></td>
				<td width="71%" style="border-style: none; border-width: medium">
				<input type="text" name="T3" size="25"></td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">KEPERLUAN</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium"><b>:</b></td>
				<td width="71%" style="border-style: none; border-width: medium">
				<input type="text" name="T4" size="25"></td>
			</tr>
			<tr>
				<td width="23%" height="26" style="border-style: none; border-width: medium">TANGGAL</td>
				<td width="2%" align="center" height="26" style="border-style: none; border-width: medium"><b>:</b></td>
				<td width="71%" height="26" style="border-style: none; border-width: medium">
				<input type="text" name="T5" size="25"></td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">Term &amp; Kondition</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium">&nbsp;</td>
				<td width="71%" style="border-style: none; border-width: medium">
				<textarea rows="12" name="S1" cols="78"></textarea></td>
			</tr>
			<tr>
				<td width="23%" style="border-style: none; border-width: medium">&nbsp;</td>
				<td width="2%" align="center" style="border-style: none; border-width: medium">&nbsp;</td>
				<td width="71%" style="border-style: none; border-width: medium">
				<input type="checkbox" name="C1" value="ON">Yes
				<input type="checkbox" name="C2" value="ON">NO</td>
			</tr>
			</table>
			<p><input type="submit" value="Submit" name="B1"><input type="reset" value="Reset" name="B2"></p>
			<p>&nbsp;</p>
		</form>
		</td>
	</tr>
</table>

</body>

</html>
