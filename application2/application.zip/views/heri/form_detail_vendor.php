    <table class="table table-bordered" id="dataTable" width="40%" cellspacing="0">
      <form>
        <td>    NIK         : <?php echo $ktp; ?></td>
      <tr>
        <td>    Nama      : <?php echo $nama; ?></td>
      </tr>
      <tr>
        <td>    Divisi      : <?php echo $perusahaan; ?></td>
       </tr>
      <tr>
        <td><img src="<?php echo base_url(); ?>foto_vendor/<?php echo $foto; ?>" width="200" height="220"></td>
      </tr>
    </form>
  </table>