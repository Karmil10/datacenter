    <table class="table table-bordered" id="dataTable" width="40%" cellspacing="0">
      <form>
        <td>    id         : <?php echo $id; ?></td>
      <tr>
        <td>    Nama      : <?php echo $nama; ?></td>
      </tr>
      <tr>
        <td>    departemen      : <?php echo $departemen; ?></td>
       </tr>
      <tr>
        <td><img src="<?php echo base_url(); ?>foto_karyawan/<?php echo $image; ?>" width="200" height="220"></td>
      </tr>
    </form>
  </table>